A Pen created at CodePen.io. You can find this one at https://codepen.io/IsaacBell/pen/xJqgXj.

 Calculating particle positions on the GPU, I don't know why I haven't done this before. This is just a rough test; I'm going to be making a refined version with controls and different particle movements.